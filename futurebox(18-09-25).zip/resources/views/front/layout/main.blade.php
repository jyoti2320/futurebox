@include('front.layout.header')
@include('front.layout.main-menu')

@yield('main-section')

@include('front.layout.footer')
@include('front.layout.footer-js')
