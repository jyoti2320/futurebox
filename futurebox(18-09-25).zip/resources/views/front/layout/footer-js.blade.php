
	<!-- jquery -->
	<script src="{{ url('front/assets/js/jquery.js') }}"></script>
	<!-- popper -->
	<script src="{{ url('front/assets/js/popper.min.js') }}"></script>
	<!-- bootstrap -->
	<script src="{{ url('front/assets/vendor/bootstrap/bootstrap.bundle.min.js') }}"></script>
	<!-- plugin js-->
	<script src="{{ url('front/assets/js/plugin.js') }}"></script>
	<script src="{{ url('front/assets/vendor/wow.min.js') }}"></script>
	<script src="{{ url('front/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>

	  <!-- Fancybox JS -->
  	<script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox/fancybox.umd.js"></script>

	<!-- MpusemoverParallax JS-->
	<script src="{{ url('front/assets/js/TweenMax.js') }}"></script>
	<script src="{{ url('front/assets/js/mousemoveparallax.js') }}"></script>

	<!-- main -->
	<script src="{{ url('front/assets/js/main.js') }}"></script>
	<script src="{{ url('front/assets/js/custom.js') }}"></script>
</body>
</html>