@extends('admin.layouts.main')
@section('main-section')
    <style>
        .cke_notification_warning {
            display: none !important;
        }
    </style>

         <!-- Content wrapper -->
          <!-- <div class="content-wrapper"> -->
          <div class="container-xxl flex-grow-1 container-p-y">
            <!-- Content -->
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row g-6">
                <!-- View sales -->
                <div class="col-xl-4">
                  <div class="card">
                    <div class="d-flex align-items-end row">
                      <div class="col-7">
                        <div class="card-body text-nowrap">
                          <h5 class="card-title mb-0">Welcome Admin! 🎉</h5>
                          <!-- <p class="mb-2">Best seller of the month</p> -->
                          <!-- <h4 class="text-primary mb-1">$48.9k</h4>
                          <a href="javascript:;" class="btn btn-primary">View Sales</a> -->
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- View sales -->

              </div>
              </div>

            </div>
            <!-- / Content -->

@endsection

